import 'package:flutter/cupertino.dart';

const String TEXT_FONT_CONST = 'Noto Sans';
// const FontWeight TEXT_BOLD_CONST = FontWeight.bold;