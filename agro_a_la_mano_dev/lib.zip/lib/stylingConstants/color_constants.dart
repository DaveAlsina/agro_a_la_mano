import 'package:flutter/cupertino.dart';

const Color BACKGROUND_COLOR = Color(0xFFECF5F3);
const Color GREEN_BUTTON_COLOR = Color(0xFF00CC76);
const Color GREY_LETTERS_COLOR = Color(0xFF707070);
const Color BLUE_LETTERS_COLOR = Color(0xFF70A2A2);
const Color LIGHT_GREEN_BUTTON_COLOR = Color(0xFFB6EBD3);
